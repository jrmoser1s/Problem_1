# side-effects: functions that change global variables.

# program with side effects.


a = 0 #global variable


def increment():
    global a
    a += 1 # increments 


# program without side effects.


def increment(a):
    return a + 1
