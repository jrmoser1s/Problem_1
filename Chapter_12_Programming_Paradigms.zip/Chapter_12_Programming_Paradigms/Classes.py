# creating classes containing methods.


class Orange: # Class
    def __init__(self, w, c): # method
        self.weight = w #instance
        self.color = c #instance
        print("Created!") #instance


or1 = Orange(10, "dark orange") # prints 'Created!'
print(or1)
print(or1.weight) #prints 10
print(or1.color) # prints 'dark orange'


# Changing value of an instance 

or1.weight = 100
or1.color = 'light orange'


print(or1.weight) # prints 100
print(or1.color) # print 'light orange'


# creating multiple objects.


or1 = Orange(4, "light orange") # prints 'Created!'
or2 = Orange(8, "dark orange") # prints 'Created!'
or3 = Orange(14, "yellow") # prints 'Created!'

