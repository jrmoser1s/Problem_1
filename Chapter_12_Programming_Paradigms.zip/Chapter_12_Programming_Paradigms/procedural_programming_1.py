# procedural programming
# programming style in which a sequence of steps are written to move toward a solution.

# example


x = 2
y = 4
z = 8
xyz = x + y + z
print(xyz)
