# multiple methods in class rectangle.


class Rectangle():  # Class Rectangle.
    """Suites"""
    def __init__(self, w, l):   # magic method, objects w & l.
        self.width = w # instance width.
        self.len = l #instance len.


    def area(self): # method area.
        return self.width * self.len


    def change_size(self, w, l): #method change_size, objects w & l
        self.width = w # instance width.
        self.len = l # instance len.


rectangle = Rectangle(10, 20)
print(rectangle.area()) #prints 200.
rectangle.change_size(20, 40)
print(rectangle.area()) #print 800.
    
