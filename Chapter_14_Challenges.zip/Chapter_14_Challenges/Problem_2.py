# prints message when printing Square object.


class Square():
   square_list = []


   def __init__(self, side_len):
        self.len = side_len
        self.square_list.append(self.len)


   def __repr__(self):
       return  "{} by {} by {} by {}. "\
              .format(self.len, self.len, self.len, self.len)


sqr1 = Square(10)
sqr2 = Square(20)
sqr3 = Square(30)

print("Sides of Square 1 are", sqr1)
print("Sides of Square 2 are", sqr2)
print("Sides of Square 3 are", sqr3)
print(Square.square_list)

