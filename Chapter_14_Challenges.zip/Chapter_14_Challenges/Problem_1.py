# Adds Square objects to list for every object created


class Square():
   square_list = []



   def __init__(self, side_len):
        self.len = side_len
        self.square_list.append(self)


sqr1 = Square(10)
sqr2 = Square(20)
sqr3 = Square(30)


print(Square.square_list)


# Alterative method adding to problem in previous chapter.


class Shape():
    def what_am_i(self):
        print("I am a shape.")


class Square(Shape):
    square_list = []

    def __init__(self, s1):
        self.s1 = s1
        self.square_list.append(self)

    def calculate_perimeter(self):
        return self.s1 * 4

    def what_am_i(self):
        super().what_am_i()
        print("I am a Square.")


a_square = Square(29)
print(Square.square_list)
another_square = Square(93)
print(Square.square_list)

