# Function takes two objects and returns whether True or false.


def true_false(x, y):
    if x is y:
        return True
    else:
        return False

    
determine = true_false('bobs','bob')
print(determine)

# Alternate method.

def compare(obj1, obj2):
    return obj1 is obj2


x = "hello"
y = "hello"


print(compare(x, y))



