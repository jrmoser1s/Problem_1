#Capital first Character in string 

inc_grammar = "aldous Huxley was Born in 1894."
cor_grammar = inc_grammar.capitalize()

print(cor_grammar)


