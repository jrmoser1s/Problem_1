# Takes list converts to string with no spacing between period

lst = ["The",
       "fox",
       "jumped",
       "over",
       "the",
       "fence",
       "."]

lst = " ".join(lst)
lst = lst[0:-2] + "."
print(lst)
