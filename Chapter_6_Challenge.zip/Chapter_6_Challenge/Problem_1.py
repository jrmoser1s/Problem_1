# Print every character in string "Camus"

author = "Camus"
print(author[0])
print(author[1])
print(author[2])
print(author[3])
print(author[4])

