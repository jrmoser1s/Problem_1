# Use Concatenation to create string 'three three three

three_threes = "three " + "three " + "three"
print(three_threes)

three_three = "three "*3
print(three_threes)
