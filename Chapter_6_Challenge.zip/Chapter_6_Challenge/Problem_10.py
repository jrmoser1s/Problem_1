#Print sliced string value before comma

strg = "It was a bright cold day in April, and the clocks were strings thirteen."

print(strg[:33])
