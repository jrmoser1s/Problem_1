# finds first instance of m

author = "Hemingway"
print(author.index("m"))
