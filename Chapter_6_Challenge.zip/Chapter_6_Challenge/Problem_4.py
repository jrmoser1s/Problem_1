# Use a method to break up string

x = "Where now?  Who now?  When now?"
lst = x.split('  ')
print(lst)
