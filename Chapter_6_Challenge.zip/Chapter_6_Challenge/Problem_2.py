#Takes two responses from user and inputs them into a string

response_one = input("Enter your first response:")
response_two = input("Enter your second response:")

print("Yesterday I wrote a {}. I sent it to {}".format(response_one,response_two))
