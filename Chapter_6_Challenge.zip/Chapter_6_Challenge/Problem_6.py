# takes every a and converts to $

sentence = "A screaming comes across the sky."
sentence = sentence.replace("s","$")
print(sentence)
