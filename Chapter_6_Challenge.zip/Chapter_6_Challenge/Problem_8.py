# Turn quote into string

print('"Fuck the Police" I said, with a grin on my face')
