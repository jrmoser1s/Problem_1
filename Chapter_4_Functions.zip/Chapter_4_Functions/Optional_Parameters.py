#optional parameters

def add_it (x, y=10):
    return x + y

result_1 = add_it(2)
result_2 = add_it(2,4)
print(result_1)
print(result_2)
