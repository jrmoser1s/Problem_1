#Reusing Functions


def even_odd():
    n = input("enter an interger ")
    n = int(n)
    if n % 2 == 0:
        print("even")
    else:
        print("odd")



even_odd()
even_odd()
even_odd()
