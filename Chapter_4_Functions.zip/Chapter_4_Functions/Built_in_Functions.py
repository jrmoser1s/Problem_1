# built-in functions

#len returns length of string
print(len("Hello, World"))

#str returns object as string object 
print(str(100))

#int return object as integer object
print(int("100"))
print(int(20.54))

#float returns object as float object
print(float("16.4"))
print(float(99))

#input function
age = input("What is your age? ")
int_age = int(age)
if int_age < 21:
    print("You are young!")
else:
    print("Wow you're old!")




