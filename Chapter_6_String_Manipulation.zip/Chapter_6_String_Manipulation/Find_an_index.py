# Find an Index

print("I hope its painless".index("i"))

# Using exception handling

try:
    print("I hope its painless".index("z"))
except:
    print("Not Found")
