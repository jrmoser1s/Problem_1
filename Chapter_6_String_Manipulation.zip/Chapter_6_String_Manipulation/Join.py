# Join

first_three = 'abc'
result = "+".join(first_three)
print(first_three)
print(result)

# Join List of words

words = ["You",
         "Are",
         "My",
         "Best",
         "Friend",
         "And",
         "I'm",
         "So",
         "Sorry",
         "."]

print(words)
print(" ".join(words))
