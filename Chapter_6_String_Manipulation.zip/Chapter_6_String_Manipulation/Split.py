# Splitting strings

print("Hello from the other side".split(" "))
