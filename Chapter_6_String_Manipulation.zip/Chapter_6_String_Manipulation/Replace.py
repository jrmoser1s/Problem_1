# Replace

question = "Why am I still at the same job?"
print(question)
question = question.replace("Why am I", "FUCK I'm")
question = question.replace("?","!")
print(question)
