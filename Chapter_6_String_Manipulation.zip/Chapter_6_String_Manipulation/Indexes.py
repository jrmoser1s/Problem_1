# Indexes of strings

author = "Kafka"
print(author[0])
print(author[1])
print(author[2])
print(author[3])
print(author[4])

print('\n')

#Negative Indexes
print(author[-1])
print(author[-2])
print(author[-3])
print(author[-4])
print(author[-5])

