#String that span multiple lines must have three quotations 

print("""line one
line two
line three""",'\n')

print('''line one
line two
line three''')

