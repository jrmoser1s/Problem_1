# String Multiplication

print("Sawyer" *3)
