# Format

print("Justin {}".format('Moser'))

last = "Moser"
print("Justin {}".format(last))

# .format multiple parameters

name = 'Justin Moser'
year = '1993'
print("{} was born in {}".format(name,year))

