# Strip

s = "       Fuck        "
print(s)
print(s.strip())
