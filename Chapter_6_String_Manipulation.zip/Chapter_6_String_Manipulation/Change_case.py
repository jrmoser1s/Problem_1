# Change case

#.upper()

print("I'm going to kill myself".upper())

# .lower()

print("I'M GOING TO KILL MYSELF".lower())

# .capitalize()

print("i'm going to kill myself".capitalize())
