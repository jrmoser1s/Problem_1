# Newline

print("line1\nline2\nline3\n")
