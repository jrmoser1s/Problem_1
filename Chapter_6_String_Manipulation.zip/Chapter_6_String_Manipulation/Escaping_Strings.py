# Escaping String

print("She sell sea \"Shells.\"")
print('She sells sea \"Shells.\"')
print('She sells sea "Shells."')
print("She sells sea 'Shells.'")

