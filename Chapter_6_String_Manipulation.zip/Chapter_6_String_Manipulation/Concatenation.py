# Concatenation

print("cat" + "in" + "hat")

print("cat" + " in" + " the " + "hat") 
