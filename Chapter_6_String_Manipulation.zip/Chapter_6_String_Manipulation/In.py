# In

print("Cat" in "Cat in the Hat")

print("Bat" in "Cat in the Hat")

print("Potter" not in "Harry")
