# Slicing a list 

# slicing list

fict = ["Tolstoy",
        "Camus",
        "Orwell",
        "Huxley",
        "Austin"]
print(fict[0:3])

# slicing string

sorry = """To all the people that I have loved
and cared for, I apologize for the person I am
and the mistakes I've made"""

print(sorry[0:62])
print(sorry[63:110])

# starting slice with first iterable

print(sorry[:62])

# ending slice with last iterable

print(sorry[63:])

# returning entire iterable

print(sorry[:])
