# Player


class Player:
    def __init__(self, name):
        self.wins = 0                   # instance wins keeps track of wins.
        self.card = None                # instances card keeps track of card player is holding. 
        self.name = name                # keeps track of the players name.
