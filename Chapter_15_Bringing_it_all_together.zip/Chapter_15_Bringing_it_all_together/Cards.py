# Cards


class Card:                             # class Card.
    suits = ("spades",                  # class variable suits as tuple of strings
             "hearts",                  # representing card suits.
             "diamonds",
             "clubs")


    values = (None, None, "2", "3",     # class variable values as tuple of strings
              "4", "5", "6" ,"7",       # representing card values.
              "8", "9", "10",
              "Jack", "Queen",
              "King", "Ace")


    def __init__(self, v, s):           # magic method __init__ to initialize values.
        """suit + value are ints"""
        self.value = v                  # instance variable value.
        self.suit = s                   # instance variable suit.


    def __lt__(self, c2):               # magic method __lt__ for less than operand.
        """
        checks whether the value
        is less than second param
        if value is equal
        then checks the suit
        to see if suit is less than.
        """
        if self.value < c2.value:       
            return True                 
        if self.value == c2.value:      
            if self.suit < c2.suit:
                return True
            else:
                return False
        return False


    def __gt__(self, c2):               # magic method __gt__ for greater than operand.
        """
        checks whether the value
        is greater than second param
        if value is equal to second param
        then checks the suit
        to see if suit is greater than.
        """
        if self.value > c2.value:
            return True
        if self.value == c2.value:
            if self.suit > c2.suit:
                return True
            else:
                return False
        return False


    def __repr__(self):
        v = self.values[self.value] + " of " \
        + self.suits[self.suit]
        return v


card1 = Card(10, 2)
card2 = Card(11, 3)
print(card1 < card2)
print(card1 > card2)


card = Card(3, 2)
print(card)
        
