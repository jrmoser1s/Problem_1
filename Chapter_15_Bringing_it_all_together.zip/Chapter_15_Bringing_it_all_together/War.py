# War Card Game.


from random import shuffle


class Card:                             # class Card.
    suits = ("spades",                  # class variable suits as tuple of strings
             "hearts",                  # representing card suits.
             "diamonds",
             "clubs")


    values = (None, None, "2", "3",     # class variable values as tuple of strings
              "4", "5", "6" ,"7",       # representing card values.
              "8", "9", "10",
              "Jack", "Queen",
              "King", "Ace")


    def __init__(self, v, s):           # magic method __init__ to initialize values.
        """suit + value are ints"""
        self.value = v                  # instance variable value.
        self.suit = s                   # instance variable suit.


    def __lt__(self, c2):               # magic method __lt__ for less than operand.
        """
        checks whether the value
        is less than second param
        if value is equal
        then checks the suit
        to see if suit is less than.
        """
        if self.value < c2.value:       
            return True                 
        if self.value == c2.value:      
            if self.suit < c2.suit:
                return True
            else:
                return False
        return False


    def __gt__(self, c2):               # magic method __gt__ for greater than operand.
        """
        checks whether the value
        is greater than second param
        if value is equal to second param
        then checks the suit
        to see if suit is greater than.
        """
        if self.value > c2.value:
            return True
        if self.value == c2.value:
            if self.suit > c2.suit:
                return True
            else:
                return False
        return False


    def __repr__(self):                 # magic method __repre__ to change what object returns.
        v = self.values[self.value] + " of " \
        + self.suits[self.suit]
        return v


class Deck:
    def __init__(self):
        """
        adds every card value and
        suit to a cards list
        then shuffles the position of
        cards in the list.
        """
        self.cards = []                 # instance variable cards with value of empty list.
        for i in range(2, 15):
            for j in range(4):
                self.cards\
                .append(Card(i, j))     # appends Card object to cards list.
        shuffle(self.cards)             # reorganizes the items in cards list.


    def rm_card(self):
        if len(self.cards) == 0:        # if no card is cards list.
            return
        return self.cards.pop()         # removes last item from cards list.


class Player:
    def __init__(self, name):
        self.wins = 0                   # instance wins keeps track of wins.
        self.card = None                # instances card keeps track of card player is holding. 
        self.name = name                # keeps track of the players name.


class Game:
    def __init__(self):
        """name1 + name2 str types."""
        name1 = input("p1 name ")       # instance variable name1 for player1 name.
        name2 = input("p2 name ")       # instance varibale name2 for player2 name.
        self.deck = Deck()              # object of Deck created to generate value and suit variables. 
        self.p1 = Player(name1)         # object of Player created to store p1 name.
        self.p2 = Player(name2)         # object of Player created to store p2 name.


    def wins(self, winner):
        w = "{} wins this round"
        w = w.format(winner)
        print(w)


    def draw(self, p1n, p1c, p2n, p2c):
        d = "{} drew {} {} drew {}"
        d = d.format(p1n, p1c, p2n, p2c)
        print(d)


    def play_game(self):
        cards = self.deck.cards         # stores cards list from deck to cards in play_game.
        print("Beginning War!")
        while len(cards) >= 2:          # runs as long as 2 or more cards in deck.
            m = "q to quit. Any " + "key to play:"
            response = input(m)
            if response == 'q':
                break
            p1c = self.deck.rm_card()   # calls random value and suit from Deck method rm_card.
            p2c = self.deck.rm_card()   # calls random value and suit from Deck method rm_card.
            p1n = self.p1.name          # p1n equal to object created by Player stored in instance name.
            p2n = self.p2.name          # p2n equal to object Created by Player stored in instance name.
            self.draw(p1n, p1c,         # pushes values to draw method.
                      p2n, p2c) 
            if p1c > p2c:
                self.p1.wins += 1       # increments p1 wins in __init__ method.
                self.wins(self.p1.name) # pushs p1 name to winner in wins method.
            else:
                self.p2.wins += 1       # increments p2 win in __init__ method.
                self.wins(self.p2.name) # pushes p2 name to winner in wins method.


        win = self.winner(self.p1, self.p2)

        print("War is over. {} wins".format(win))


    def winner(self, p1, p2):
        if p1.wins > p2.wins:
            return p1.name
        if p1.wins < p2.wins:
            return p2.name
        return "It was a tie!"


game = Game()                           # creates Game object game.
game.play_game()

while True:                   
    play_again = input("y to play again. Any key to quit")
    if play_again == 'y':
        game = Game()
        game.play_game() 
    else:
       break
    

            
