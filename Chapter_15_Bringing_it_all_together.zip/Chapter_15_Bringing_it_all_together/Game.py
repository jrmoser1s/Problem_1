# Game


class Game:
    def __init__(self):
        """name1 + name2 str types."""
        name1 = input("p1 name ")       # instance variable name1 for player1 name.
        name2 = input("p2 name ")       # instance varibale name2 for player2 name.
        self.deck = Deck()              # object of Deck created to generate value and suit variables. 
        self.p1 = Player(name1)         # object of Player created to store p1 name.
        self.p2 = Player(name2)         # object of Player created to store p2 name.


    def wins(self, winner):
        w = "{} wins this round"
        w = w.format(winner)
        print(w)


    def draw(self, p1n, p1c, p2n, p2c):
        d = "{} drew {} {} drew {}"
        d = d.format(p1n, p1c, p2n, p2c)
        print(d)


    def play_game(self):
        cards = self.deck.cards         # stores cards list from deck to cards in play_game.
        print("Beginning War!")
        while len(cards) >= 2:          # runs as long as 2 or more cards in deck.
            m = "q to quit. Any " + "key to play:"
            response = input(m)
            if response == 'q':
                break
            p1c = self.deck.rm_card()   # calls random value and suit from Deck method rm_card.
            p2c = self.deck.rm_card()   # calls random value and suit from Deck method rm_card.
            p1n = self.p1.name          # p1n equal to object created by Player stored in instance name.
            p2n = self.p2.name          # p2n equal to object Created by Player stored in instance name.
            self.draw(p1n, p1c,         # pushes values to draw method.
                      p2n, p2c) 
            if p1c > p2c:
                self.p1.wins += 1       # increments p1 wins in __init__ method.
                self.wins(self.p1.name) # pushs p1 name to winner in wins method.
            else:
                self.p2.wins += 1       # increments p2 win in __init__ method.
                self.wins(self.p2.name) # pushes p2 name to winner in wins method.


        win = self.winner(self.p1, self.p2)

        print("War is over. {} wins".format(win))


    def winner(self, p1, p2):
        if p1.wins > p2.wins:
            return p1.name
        if p1.wins < p2.wins:
            return p2.name
        return "It was a tie!"
