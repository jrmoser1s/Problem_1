# Call another item from statistics list


import statistics

nums = [1,3,2,5,7,6]
print(statistics.stdev(nums))
print(statistics.variance(nums))
print(statistics.quantiles(nums))
