# Cubed Fuction


# code in function.
def cubed(x):
    '''
    returns cubic value of x.
    :return: int x cubed
    '''
    return x**3
