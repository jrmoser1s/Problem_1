# Import cubic function from function.py and prints value.

import function
print(function.cubed(5))



