# takes input from a user and enters it into file.


answer = input("How are you feeling today? ")

with open("Problem_2.txt", "w+") as f:
    f.write(answer)

with open("Problem_2.txt", "r") as g:
    print(g.read())




