# takes list and puts them into .csv file


import csv



movies = [["Top Gun",
           "Risky Business",
           "Minority Report"], 
          ["Titanic",
           "The Revenant",
           "Inception"], 
          ["Training Day",
           "Man on Fire",
           "Flight"]
          ]

with open("Problem_3.csv", "w",newline='') as csvfile:
    csvfile_write = csv.writer(csvfile,
                   delimiter=",")
    for movie_list in movies:
        csvfile_write.writerow(movie_list)
