# find file on computer and read contents of file.

with open(r"C:\Users\Justin Moser\Desktop\Hello_Other.txt", "r") as f:
    print(f.read())
