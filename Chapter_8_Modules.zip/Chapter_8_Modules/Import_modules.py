# Importing Built-in module math.


import math


print(math.pow(2,3))


# Importing Built-in module random.


import random


print(random.randint(0,1000))


# Importing Built-in module statistics.


import statistics

# mean
nums = [1, 5, 33, 12, 46, 33, 2]
print(statistics.mean(nums))


#median
print(statistics.median(nums))


#mode
print(statistics.mode(nums))


# Importing Built-in module keyword.


import keyword


print(keyword.iskeyword("for"))
print(keyword.iskeyword("import"))
print(keyword.iskeyword("football"))
