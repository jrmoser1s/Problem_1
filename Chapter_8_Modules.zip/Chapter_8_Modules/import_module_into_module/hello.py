# hello.py


def print_hello():
    print("Hello")
