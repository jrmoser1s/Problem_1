# moduel2.py


# code in module2
import module1

