# create a class to calculate perimeter of hexagon.


class Hexagon():
    """Side len in mm"""
    def __init__(self,s1, s2, s3, s4, s5, s6):
        self.s1 = s1
        self.s2 = s2
        self.s3 = s3
        self.s4 = s4
        self.s5 = s5
        self.s6 = s6


    def perimeter_calculator(self):
        return self.s1 + self.s2 + self.s3 + self.s4 + self.s5 + self.s6


# Ask user to input the six sides of the Hexagon.

print("Perimeter Calculator for Hexagon.")
sides = []
n = 1
side_num = ["first","second","thrid","forth","fifth","sixth"]
while n <= 6:
    side = input("Enter the {} side of the Hexagon. q to quit ".format(side_num[n-1]))
    if side == 'q':
        break
    try:
        side = int(side)
        sides.append(side)
        n += 1
        if n == 7:
            hexagon = Hexagon(sides[0],
                              sides[1],
                              sides[2],
                              sides[3],
                              sides[4],
                              sides[5])
            print("\nPerimeter of the Hexgon is {}mm.\n"\
                  .format(hexagon.perimeter_calculator()))
            sides = []
            n = 1
            print("Perimeter Calculator for Hexagon.")
    except ValueError:
        print("Invalid Input.")
        

