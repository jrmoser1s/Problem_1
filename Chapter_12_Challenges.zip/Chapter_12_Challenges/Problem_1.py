# Create Class Apple w/ 4 instances represtenting attributes.


class Apple:
    def __init__(self, weight, color, apple_type, taste):
        '''weight in oz\
        '''
        self.weight = weight
        self.color = color
        self.apple_type = apple_type
        self.taste = taste


apple = Apple(10, 'pink', 'pink lady', 'sweet')
print(apple.weight)
print(apple.color)
print(apple.apple_type)
print(apple.taste)
