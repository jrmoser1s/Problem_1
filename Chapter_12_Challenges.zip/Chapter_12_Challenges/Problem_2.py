# created class to calculate area of circle.


import math


class Circle():
    '''radius in mm'''
    def __init__(self, radius):
        self.radius = radius


    def area(self):
        return self.radius **2 * math.pi


while True:
    radius = input("Enter radius of Circle. q to quit")
    if radius == 'q':
        break
    try:
        radius = int(radius)
        circle = Circle(radius)
        print(circle.area())
    except ValueError:
        print("Invalid Input")
    
