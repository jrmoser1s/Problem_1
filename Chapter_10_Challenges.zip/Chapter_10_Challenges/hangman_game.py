# hangman game

import hangman

hangman.game()

while True:
    play_again = input("Enter y to play again or n to quit. ")
    if play_again != 'y' or 'n':
        print("Not a valid input!")
    if play_again == 'n':
        break
    if play_again == 'y':
        hangman.game()
    


