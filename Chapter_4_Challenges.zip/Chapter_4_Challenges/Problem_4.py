#Two functions, using result from first to Calc the second.

def divide(x):
    """
    Returns x/2.
    :param x: int.
    :return: float quotient of x and 2.
    """
    return x/2

def multiply(x):
    """
    Returns x*4.
    :param x: float
    :return: float product of x and 4.
    """
    return x*4
    
div_result = divide(1)
print(div_result)
mult_result = multiply(div_result)
print(mult_result)
