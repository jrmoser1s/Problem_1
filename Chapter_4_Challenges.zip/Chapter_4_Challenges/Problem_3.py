#Function w/ 3 required params & 2 optional params

def add(a,b,c,x=1,y=2):
    """
    Returns a + b + c + x + y.
    :param a: int.
    :param b: int.
    :param c: int.
    :param x: int.
    :param y: int.
    :return: int sum of a, b, c, x, and y
    """
    return a+b+c+x+y

print(add(10,11,12))
print(add(10,10,10,10,10))
