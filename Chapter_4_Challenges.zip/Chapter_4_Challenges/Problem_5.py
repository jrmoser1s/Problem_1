#Converts String into float with exception handling for errors

def convert(string):
    """
    Returns passed in str to float
    :param string: str
    :return: string converted into float
    """
    try:
        return float(string)
    except ValueError:
        print("Could not convert string to a float.")

c = convert("55.0")
print(c)

