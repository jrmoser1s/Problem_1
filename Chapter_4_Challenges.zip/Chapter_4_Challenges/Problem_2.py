#print string entered to function

def print_string(string):
    """
    Prints x
    :param x: str.
    :print: str value x
    """
    print(string)

print_string("Hello, World!")
