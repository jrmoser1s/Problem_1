#takes input and squares value


def squared(x):
    """
    Returns x**2
    :param x: int
    :return: int square of x 
    """
    return x**2

print(squared(12))
