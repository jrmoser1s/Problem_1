# Esaping


import re


line = "I love $"


m = re.findall("\\$",
               line,
               re.IGNORECASE)


print(m)    # ['$']


# bash equivalent:
# echo I love $ | grep \\$
