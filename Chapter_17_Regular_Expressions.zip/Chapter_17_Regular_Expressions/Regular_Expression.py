# re module


import re                               # Regular Expression Built-in module.


l = "Beautiful is better than ugly."    # string parameter.


matches = re.findall("Beautiful",       # First pass Regular expression as parameter.
                     l)                 # Second pass sting.
     


print(matches)                          # returns a list with all items in string pattern
                                        # matches.

matches = re.findall("beautiful",
                     l,
                     re.IGNORECASE)     # pass IGNORECASE as third param to ingore Case senitivity.


print(matches)

# bash equivalent:
# (as long as you are in the directory containing zen.txt.)
# grep Beautiful zen.txt
# grep -i beautiful zen.txt

