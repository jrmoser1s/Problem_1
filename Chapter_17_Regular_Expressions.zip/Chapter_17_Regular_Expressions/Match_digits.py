# match digits


import re


string = "123 hi 34 hello."

# \d to find digits in string.
m = re.findall("\d",
               string,
               re.IGNORECASE)


print(m) #['1', '2', '3', '3', '4']

# bash equivalent:
# echo 123 hi 34 hello. | grep [[:digit:]]
