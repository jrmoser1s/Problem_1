# repition

# bash code:

# echo two twoo not too. | grep -o two*
# two
# twoo

# echo __hello__ | grep -o __.*__
# __hello__

# echo __hi__bye__hi__there. | grep -o __.*__
# __hi__bye__hi__


# Python Repition


import re


string = "__one__ __two__ __three__"


m = re.findall("__.*?__", string)

for match in m:
    print(match)
