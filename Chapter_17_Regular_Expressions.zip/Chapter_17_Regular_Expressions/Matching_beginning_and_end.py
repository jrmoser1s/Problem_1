# Match beginning and End.


import re


zen = """Although never is
often better than
*right* now.
If the implementation
is hard to explain,
it's a bad idea.
If the implementation
is easy to explain,
it may be a good
idea. Namespaces
are one honking
great idae -- let's
do more of those!
"""

# match beginning of line.
m = re.findall("^If",
               zen,
               re.MULTILINE)
# match end of line.
n = re.findall("idea.$",
               zen,
               re.MULTILINE)
print(m)
print(n)

# bash equivalent.
# (as long as you are in the directory containing zen.txt)
# grep ^If zen.txt
# grep idea.$ zen.txt (doesn't seem to work for me...)
