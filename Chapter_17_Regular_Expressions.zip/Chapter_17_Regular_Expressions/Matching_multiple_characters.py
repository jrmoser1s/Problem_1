# matching multiple characters.


import re


string = "Two too."

# matching first char, the looks for either char in bracket, and then last character to match.
m = re.findall("t[ow]o",
               string,
               re.IGNORECASE)


print(m) # ['Two', 'too']
