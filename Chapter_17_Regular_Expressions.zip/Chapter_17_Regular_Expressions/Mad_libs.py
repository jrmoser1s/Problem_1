# mad libs
# Using Regular Expressions method.


import re


text = """Giraffes have aroused
the curiosity of __PLURAL_NOUN__
since earliest times. The
giraffe is the tallest of all
living __PLURAL_NOUN__, but
scientists are unable to
explain how it got its long
__PART_OF_THE_BODY__. The
giraffe's tremendous height,
which might reach __NUMBER__
__PLURAL_NOUN__, comes from
its legs and __BODYPART__.
"""

def mad_libs(mls):
    """
    :param mls: string
    with parts the user
    should fill out surrounded
    by double underscores.
    Underscores cannot
    be inside hint e.g., no
    __hint_hint___ only
    __hint__.
    """
    hints = re.findall("__.*?__",               # ['__PLURAL_NOUN__', '__PLURAL_NOUN__', '__PART_OF_THE_BODY__', '__NUMBER__',
                       mls)                     # __PLURAL_NOUN__, '__BODYPART__']
    if hints is not None:                       # As long as regular method is able to find items in hints list.
        for word in hints:                      # Iterates through every item in list.
            q = "Enter a {} ".format(word)
            new = input(q)
            mls = mls.replace(word, new, 1)     # Replaces word with new, and only replace the 1 instance.
        print('\n')
        mls = mls.replace("\n", " ")            # Replace newline with a space.
        print(mls)
    else:
        print("Invalid mls")


mad_libs(text)
            
