# Create two classes Square and Rectangle.
# both with a method perimeter calculator.


class Square():
    def __init__(self, side):
        self.side = side


    def calculate_perimeter(self):
        return 4 * self.side


class Rectangle():
    def __init__(self, w, l):
        self.width = w
        self.len = l


    def calculate_perimeter(self):
        return 2 * (self.width + self.len)
   


square = Square(10)
rectangle = Rectangle(10, 20)

print(square.calculate_perimeter())
print(rectangle.calculate_perimeter())
