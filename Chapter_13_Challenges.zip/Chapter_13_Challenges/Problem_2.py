# Add method to Square Class.
# Will add original side value, negitive numbers will subtract.


class Square():
    def __init__(self, side):
        self.side = side


    def calculate_perimeter(self):
        return 4 * self.side


    def change_size(self, newsize):
        self.newsize = newsize
        self.side += self.newsize


square = Square(4)
print(square.calculate_perimeter())

square.change_size(-2)
print(square.calculate_perimeter())
