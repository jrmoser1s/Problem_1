# Composition Method for Horse and Rider.


class Horse():
    def __init__(self, name, rider):
        self.name = name
        self.rider = rider


class Rider():
    def __init__(self, name):
        self.name = name


alex = Rider("Alexander the Great")
bucephalus = Horse("Bucephalus", alex)


print("The Horse is named {}".format(bucephalus.name))
print("The Riders is named {}".format(bucephalus.rider.name))
                   
    
