# Rectangle and Square inherit from Shape.
# Shape parent class, rectangle and square are children classes.
# calls method from Shape Class.


class Shape():
    def what_am_i(self):
        print("I am a shape.")


class Square(Shape):
    def __init__(self, side):
        self.side = side


    def calculate_perimeter(self):
        return 4 * self.side


class Rectangle(Shape):
    def __init__(self, w, l):
        self.width = w
        self.len = l


    def calculate_perimeter(self):
        return 2 * (self.width + self.len)


a_square = Square(29)
a_rectangle = Rectangle(20, 50)

a_rectangle.what_am_i()
a_square.what_am_i()

print(a_square.calculate_perimeter())
print(a_rectangle.calculate_perimeter())
    
