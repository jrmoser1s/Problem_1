# Print each item in list and their index

shows = ["The Walking Dead",
         "Entourage",
         "The Sopranos",
         "The Vampire Diaries"]
for i, tv in enumerate(shows):
    print(i)
    print(tv)

# alterative method


shows = ["The Walking Dead",
         "Entourage",
         "The Sopranos",
         "The Vampire Diaries"]
i = 0
for tv in shows:
    print(i)
    print(tv)
    i += 1
