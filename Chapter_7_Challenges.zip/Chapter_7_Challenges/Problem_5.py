# multiple a list with all num in another list and store results in a third list.


list1 = [8,19,148,4]
list2 = [9,1,33,83]
multiple_list = []
for i in list1:
    for j in list2:
        multiple_list.append(i*j)


print(multiple_list)

# alternative method.


list1 = [8, 19, 148, 4]
list2 = [9, 1, 33, 83]
list3 = []

for i in list1:
    for j in list2:
        mult = i * j
        list3.append(mult)

print(list3)
