# Print all numbers from 25 to 50


for i in range(25, 51):
    print(i)
