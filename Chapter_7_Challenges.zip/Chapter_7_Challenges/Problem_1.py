# Print each item in a list

shows = ["The Walking Dead",
         "Entourage",
         "The Sopranos",
         "The Vampire Diaries"]
for tv in shows:
    print(tv)
