# Guess number in list or press q to quit 


num_list = ["24","21","13","74","1"]
correct = 0
incorrect = 0
while True:
    guess = input("Guess a number on a list or press q to quit. ")
    if guess == 'q':
        break
    if guess in num_list:
        print("Correct! Number is in List.")
        correct += 1
    else:
        print("Incorrect! Number is not in List.")
        incorrect += 1


print("You were correct", correct, "times")
print("You were incorrect", incorrect, "times")

# alternative method


numbers = [11, 32, 33, 15, 1]
correct = 0
incorrect = 0
while True:
    answer = input("Guess a number or type q to quit.")
    if answer == 'q':
        break
    try:
        answer = int(answer)
    except ValueError:
        print("Please type a number or q to quit.")
    if answer in numbers:
        print("You guessed correctly!")
        correct += 1
    else:
        print("You guess incorrectly!")
        incorrect += 1

print("You were correct", correct, "times")
print("You were incorrect", incorrect, "times")
