# Anagram. Words that can be arranged to spell different words.


def anagram(w1, w2):
    w1 = w1.lower()
    w2 = w2.lower()
    return sorted(w1) == sorted(w2)     # sorted command returns string in alaphbetical order.


print(anagram("iceman", "cinema"))
print(anagram("leaf", "tree"))
