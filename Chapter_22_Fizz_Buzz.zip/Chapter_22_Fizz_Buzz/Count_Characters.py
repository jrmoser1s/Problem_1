# Counter Character Occurance.


def count_characters(string):
    count_dict = {}
    for c in string:
        if c in count_dict:         # if c key in dictionary.
            count_dict[c] += 1      # will increment key int value.
        else:
            count_dict[c] = 1       # first time through for loop will add c to dictionary with key int value of 1.

    print(count_dict)


count_characters("Dynasty")
