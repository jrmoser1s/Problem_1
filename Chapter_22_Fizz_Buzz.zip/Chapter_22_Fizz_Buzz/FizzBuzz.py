# FizzBuzz


def fizz_buzz():
    for i in range(1, 101):
        if i % 3 == 0 and i % 5 ==0:    # Using modulo operator to return remainder, if remainder of i divisible by both 3 and 5 is 0.
            print("Fizz Buzz")
        elif i % 3 == 0:                # Using modulo operator to return remainder, if remainder of i divisible by 3 is 0.
            print("Fizz")
        elif i % 5 == 0:                # Using modulo operator to return remainder, if remainder of i divisible by 5 is 0.
            print("Buzz")
        else:
            print(i)


fizz_buzz()
