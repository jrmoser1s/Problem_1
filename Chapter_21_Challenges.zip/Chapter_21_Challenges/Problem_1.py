# reverse the work yesterday uing stack method.


class Stack:
    def __init__(self):     # Magic method __init__.
        self.items = []     # instance variable items.


    def is_empty(self):     # Method is_empty. Returns True if empty, False if not empty.
        return self.items == []


    def push(self, item):   # Method push. Adds items to stack.
        self.items.append(item)


    def pop(self):          # Method pop. Removes last item to stack. Returns removed value.
        return self.items.pop()


    def peek(self):         # Method peek. Looks at last item in stack, returns value.
        last = len(self.items) - 1
        return self.items[last]

    
    def size(self):         # Method size. Returns the length of stack.
        return len(self.items)



stack = Stack()
word = "yesterday"
reverse = ''

for char in word:
    stack.push(char)


for i in range(len(stack.items)):
          reverse += stack.pop()


print(reverse)
