# match words in string ending with two o's


# not sure why this works...
"""
bash equivalent:
echo The ghost that says boo haunts the loo. | grep -i [^*]oo

Alternate method
echo The ghost that says boo haunts the loo. | grep -i .oo
"""


import re


string = "The ghost that says boo haunts the loo."


m = re.findall("[^*]oo",
               string,
               re.IGNORECASE)

print(m)


# alternate method


m = re.findall(".oo",
               string,
               re.IGNORECASE)

print(m)
