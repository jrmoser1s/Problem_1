# matches all digits in string.


"""
bash equivanlent:
echo Arizona, 497, 501, 870. California, 209, 213, 650. | grep [[:digit:]]
"""


import re


string = "Arizona, 497, 501, 870. California, 209, 213, 650."


m = re.findall("\d",
               string,
               re.IGNORECASE)


print(m)
