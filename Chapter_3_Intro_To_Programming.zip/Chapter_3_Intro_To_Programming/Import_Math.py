#using math functions

import math

# length of diagonal
l = 4
w = 5
d = math.sqrt(l**2+w**2)
print(d)
