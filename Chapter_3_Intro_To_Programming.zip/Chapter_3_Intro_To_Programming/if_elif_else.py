#using if-elif-else

x = 100
if x == 10:
    print("10!")
elif x == 20:
    print("20!")
else:
    print("100!")

if x == 100:
    print("x equals 100!")

if x % 2 == 0:
    print("x is even")
else:
    print("x is odd")
    

    
