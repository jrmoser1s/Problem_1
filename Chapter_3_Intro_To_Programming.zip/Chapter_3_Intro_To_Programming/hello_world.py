#beginning to all programming

print("Hello, World!")
