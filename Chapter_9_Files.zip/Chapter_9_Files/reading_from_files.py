# Reading from file


st = open("st.txt", "r")
print(st.read())
st.close()

# Reading from files and automatically closing them


with open("auto_closing.txt", "r") as f:
    print(f.read())
