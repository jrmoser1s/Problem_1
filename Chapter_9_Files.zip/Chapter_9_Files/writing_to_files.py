# writing to .txt file called st.txt.

st = open("st.txt","w")
st.write("Hi from Python!")
st.close()

# writing to .txt file called st.txt and automatically closing file.

with open ("auto_closing.txt", "w") as f:
    f.write("Hi from Python!")

