# defining File_Path 

import os
os.path.join("Users",
             "Justin Moser",
             "st.txt")
