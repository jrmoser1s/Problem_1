# Encapsulation.


class Data: # Class Data.
    def __init__(self): # Magic Method __init__.
        self.nums = [1, 2, 3, 4, 5] # Instance nums.


    def change_data(self, index, n): # Method change_data.
        self.nums[index] = n # Instanced nums, index, n.

# Client
data_one = Data() # Creating Data object data_one.
data_one.nums[0] = 100 # Directly Accessing nums Instance.
print(data_one.nums)


data_two = Data() #Creating Data object data_two.
data_two.change_data(0, 100)
print(data_two.nums)
