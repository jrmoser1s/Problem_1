# Polymorphism
# presenting the same interface for different data types.

# same interface presenting different types of data.


print("Hello, World!") # 'str'
print(200) # 'int'
print(200.1) # 'float'


type("Hello, World!") # <class 'str'>
type(200) # <class 'int'>
type(201) # <class 'float'>
