# Private vs. Public Methods.


class PublicPrivateExample: # class PublicPrivateExample
    def __init__(self): # magic method __init__
        self.public = "safe" # instance public
        self.private = "unsafe" # instance private


    def public_method(self): # public method public_method
        # clients can use this
        pass


    def _unsafe_method(self): # private method _unsafe_method
        # clients should not use this
        pass
    
