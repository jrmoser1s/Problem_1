# Method overriding


class Shape():                  # parent class Shape.
    """Suite"""
    def __init__(self, w, l):   # magic method, instances variables w, and l.
        self.width = w          # instance width.
        self.len = l            # instance len.


    def print_size(self):       # method print_size
        print("""{} by {}
              """.format(self.width,
                         self.len))


class Square(Shape):            # child class Sqaure.
    """Suites"""
    def area(self):             # method area.
        return self.width * self.len


    def print_size(self):       # overiding method print_size.
        print("""I am {} by {}
              """.format(self.width,
                         self.len))


a_shape = Shape(20, 20)         # created object a_shape.
a_shape.print_size()
a_square = Square(20,20)        # created object a_square.
a_square.print_size()
        
    
