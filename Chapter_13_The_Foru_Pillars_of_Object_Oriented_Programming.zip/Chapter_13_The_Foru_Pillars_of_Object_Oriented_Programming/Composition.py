# Composition
# storing an object as a variable in another object


class Dog():                    # class Dog.
    def __init__(self,          # magic method __init__.
                 name,
                 breed,
                 owner):        
        self.name = name        # instance name.
        self.breed = breed      # instance breed.
        self.owner = owner      # instance owner.


class Person():                 # class Person.
    def __init__(self, name):   # magic method __init__.
        self.name = name        # instance name.


mick = Person("Mick Jagger")    # Person object mick, instace variable name.
stan = Dog("Stanley",           # Dog object stan, instance variable name, breed, owner.
           "Bulldog",
           mick)
print(stan.owner.name)
