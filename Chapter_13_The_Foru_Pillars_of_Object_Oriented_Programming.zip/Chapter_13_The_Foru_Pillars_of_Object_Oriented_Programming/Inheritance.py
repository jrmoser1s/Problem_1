# Inheritance


class Shape():                  # parent class.
    """Suites"""
    def __init__(self, w, l):   # magic method.
        self.width = w          # instance width.
        self.len = l            # instance len.


    def print_size(self):       # method print_size.
        print("""{} by {}""".format(self.width,
                                    self.len))


class Square(Shape):            # child class.
    """Suite"""
    pass                        # do nothing.


a_square = Square(20,20)        # object a_square.
a_square.print_size()
