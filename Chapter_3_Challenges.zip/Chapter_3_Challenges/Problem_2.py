#prints either one or the other

x = 10
if x < 10:
    print("less than 10")
else:
    print("greater than or equal to 10")
