#print 3 different strings

print("Hello From the Other Side")
print("I must've called a 1000 times")
print\
("""To tell you sorry
for breaking your heart""")
