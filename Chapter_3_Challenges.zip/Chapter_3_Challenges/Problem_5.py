#divides two values prints quotient

print(7//3)
