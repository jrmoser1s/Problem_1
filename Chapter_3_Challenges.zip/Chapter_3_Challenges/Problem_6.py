#prints string based on age

age = 1
if age == 1:
    print("Hello There")
    age += 1
if age == 2:
    print("General Kenobi!")
    age += 1
if age == 3:
    print("You're a Bold One")
    
