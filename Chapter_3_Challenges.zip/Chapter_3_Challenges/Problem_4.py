#divide two values and prints remainder

y = 3
x = 4
print(x%y)

