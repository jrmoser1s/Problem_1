#prints message 1 of 3 strings

x = 1
if x < 10:
    print("x is less than 10")
if x > 10 and x <= 25:
    print("""x is great than 10 but
less than or equal to 25""")
if x > 25:
    print("x is greater than 25")
    
