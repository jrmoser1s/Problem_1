# magic methods __repr__.


class Tiger:
    def __init__(self, name):   # magic method __init__
        self.name = name        # instance variable name.


tiger = Tiger("Dilbert")
print(tiger)                # prints the objects location by calling magic method __repr__.


# overriding __repr__ magic method.


class Lion:
    def __init__(self, name):   # magic method __init__.
        self.name = name        # instance variable name.
 

    def __repr__(self):     # magic method __repr__.
        return self.name    # Overriding __repr__ method to return instance variable value.


lion = Lion("Dilbert")      # Creates object lion.
print(lion)                 # prints return from calling __repr__ magic method.


# override __add__ magic method.


class AlwaysPositive():
    def __init__(self, number):
        self.n = number


    def __add__(self, other):
        return abs(self.n +
                   other.n)


x = AlwaysPositive(-20)
y = AlwaysPositive(10)


print(x + y)
