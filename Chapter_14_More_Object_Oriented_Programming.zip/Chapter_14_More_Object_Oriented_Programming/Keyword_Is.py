# is keyword.
# returns true if two objects are the same object.
# returns false if not.


class Person:               # class Person.
    def __init__(self):     # magic method __init__.
        self.name = 'Bob'   # instance variable name.


bob = Person()              # created class object bob.
same_bob = bob              # same_bob is the same as the class object bob.
print(bob is same_bob)      # prints TRUE.

another_bob = Person()      # created another class object anohter_bob.
print(bob is another_bob)   # prints FALSE.


# if checking for None.

x = 10
if x is None:
    print("x is None :( ")
else:
    print("x is not None")


x = None
if x is None:
    print("x is None :( ")
else:
    print("x is not None")
