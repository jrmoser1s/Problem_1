# Accessing Class Variables



class Rectangle():
    recs = []                   # class variable recs.

    
    def __init__(self, w, l):   # magic Method __init__.
        self.width = w          # instace variable width.
        self.len = l            # instance variable len.
        self.recs.append((self.width,self.len))     



    def print_size(self):       # method print_size.
        print("""{} by {}
              """.format(self.width,
                         self.len))


r1 = Rectangle(10,24)           # created object r1.
r2 = Rectangle(20, 40)          # created object r2.
r3 = Rectangle(100, 200)        # created object r3.


print(Rectangle.recs)

        
