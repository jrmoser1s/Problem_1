# list of places lived

current = (38.60089, -90.4329)
college = (37.3059 , 89.5181 )
childhood = (38.597385, -90.416875)

places = [current, college, childhood]

# alternative

locations = [(38.60089, -90.4329), (37.3059 , 89.5181 ),(38.597385, -90.416875)]
