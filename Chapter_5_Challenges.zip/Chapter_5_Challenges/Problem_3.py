# dictionary of attributes

attributes = {"height":
              "6.3",
              "fav_color":
              "blue",
              "fav_author":
              "R. L. Stein"
              }


