# dictionary of attributes

attributes = {"height":
              "6.3",
              "fav_color":
              "blue",
              "fav_author":
              "R. L. Stein"
              }


n = input("Enter height, fav_color or fav_author: ")
if n in attributes:
    attribute = attributes[n]
    print(attribute)
else:
    print("Not an attribute")
