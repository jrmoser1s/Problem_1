# Store Favorite songs in list and mapp them to artist using Dictionary 

modest_songs = ["Dashboard",
                "Float On",
                "Good Times are Killing Me"]

flaming_songs = ["Superman",
                 "Trying to Explain",
                 "Yoshimi Battles the Giant pink robots"]

beatles_songs = ["Rocky Racoon",
                 "While my Guitar Gently Weeps",
                 "Help!"]

artists = {"Modest Mouse":
           modest_songs,
           "Flaming Lips":
           flaming_songs,
           "The Beatles":
           beatles_songs}

# alternative method 

songs = {"Modest Mouse":
         ["Dashboard",
          "Float On",
          "Good Times are Killing Me"],


         "Flaming Lips":
         ["Superman",
          "Trying to Explain",
          "Yoshimi Battles the Giant pink robots"],


         "The Beatles":
         ["Rocky Racoon",
          "While my Guitar Gently Weeps",
          "Help!"]
}
         

         
         
