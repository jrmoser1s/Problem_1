# Create a list of favorite Musicians

fav_musicians = ["Kurt Cobain",
             "The Beatles",
             "My Chemical Romance",
             "The Flaming Lips",
             "Modest Mouse"]

