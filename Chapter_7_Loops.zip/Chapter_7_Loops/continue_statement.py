# continue-statement


for i in range(1,6):
    if i == 3:
        continue
    print(i)

# Usig while-loop and continue statement


i = 1
while i <= 5:
    if i == 3:
        i += 1
        continue
    print(i)
    i += 1
