#break-statement to run loop only once.

for i in range(0,100):
    print(i)
    break

#break-statement to exit infinite while-loops.


qs = ["What is your name?",
      "What is your favorite color?",
      "Whats is your quest?"]
answers = []
n = 0
while True:
    print("Type q to quit.")
    a = input(qs[n])
    if a == "q":
        break
    n = (n+1) % 3
    answers.append(a)
    """
    add to list
    """


print(answers)
    
    
