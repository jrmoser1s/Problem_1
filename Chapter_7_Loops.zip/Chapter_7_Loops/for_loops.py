#for-loop to iterate through char in str.


name = 'Ted'
for character in name:
    print(character)
    
#for-loops to iterate through item in tuple.


coms = ("A. Developement",
        "Friends",
        "Always Sunny")
for show in coms:
    print(show)

#for-loop to iterate through keys in dict.


people = {"G. Bluth II":
          "A. Developement",
          "Barney":
          "HIMYM",
          "Dennis":
          "Always Sunny"
          }

for character in people:
    print(character)

#for-loops to change items in a mutable iterable.


tv = ["GOT",
      "Narcos",
      "Vice"]
i = 0
for show in tv:
    new = tv[i]
    new = new.upper()
    tv[i] = new
    i += 1


print(tv)

#for-loop moving data between two mutable iterables.


tv = ["GOT", "Narcos",
      "Vice"]
coms = ["Arrested Delevopement",
        "friends",
        "Always Sunny"]
all_shows = []


for show in tv:
    show = show.upper()
    all_shows.append(show) 


for show in coms:
    show = show.upper()
    all_shows.append(show)


print(all_shows)
