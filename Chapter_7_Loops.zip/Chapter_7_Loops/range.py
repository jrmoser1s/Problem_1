#Using Range to create sequence of numbers and for-loop to iterate through them.


for i in range(1,11):
    print(i)
