#while-loops


x = 10
while x > 0:
    print( '{}'.format(x))
    x -= 1
print("Happy New Year!")



#infinite while-loops
#press cntrl-c on keyboard to stop 


while True:
    print("Hello, World")
    break 
