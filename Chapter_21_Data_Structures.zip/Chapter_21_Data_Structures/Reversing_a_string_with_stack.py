# reverse a string with a stack.


class Stack:
    def __init__(self):     # Magic method __init__.
        self.items = []     # instance variable items.


    def is_empty(self):     # Method is_empty. Returns True if empty, False if not empty.
        return self.items == []


    def push(self, item):   # Method push. Adds items to stack.
        self.items.append(item)


    def pop(self):          # Method pop. Removes last item to stack. Returns removed value.
        return self.items.pop()


    def peek(self):         # Method peek. Looks at last item in stack, returns value.
        last = len(self.items) - 1
        return self.items[last]

    
    def size(self):         # Method size. Returns the length of stack.
        return len(self.items)


stack = Stack()             # Create Stack object stack
for c in "Hello":           # Iterates through each characters in "Hello"
    stack.push(c)           # Pushes character to stack.


reverse = ""                # empty string reverse.


for i in range(len(stack.items)):
    reverse += stack.pop()  # adds each iteration of removed character to reverse.


print(reverse)
