# Queuses


class Queue:
    def __init__(self):                 # Magic Method __init__. 
        self.items = []                 # Instance items, with variable parameters empty list.


    def is_empty(self):                 # Method is_empty. If list is empty True, if empty Fasle.
        return self.items == []


    def enqueue(self, item):            # Method enueue. Inserts item into first position of list.
        self.items.insert(0, item)      


    def dequeue(self):                  # Method dequeue. Returns last item removed from list.
        return self.items.pop()


    def size(self):                     # Method size. Returns length of list.
        return len(self.items)


a_queue = Queue()
print(a_queue.is_empty())


a_queue = Queue()


for i in range(5):
    a_queue.enqueue(i)


print(a_queue.size())


a_queue = Queue()


for i in range(5):
    a_queue.enqueue(i)


for i in range(5):
    print(a_queue.dequeue())


print()


print(a_queue.size())
