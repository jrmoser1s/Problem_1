# Ticket Que


import time
import random


class Queue:
    def __init__(self):                 # Magic Method __init__. 
        self.items = []                 # Instance items, with variable parameters empty list.


    def is_empty(self):                 # Method is_empty. If list is empty True, if empty Fasle.
        return self.items == []


    def enqueue(self, item):            # Method enueue. Inserts item into first position of list.
        self.items.insert(0, item)      


    def dequeue(self):                  # Method dequeue. Returns last item removed from list.
        return self.items.pop()


    def size(self):                     # Method size. Returns length of list.
        return len(self.items)


    def simulate_line(self,             # Method simulate_line. Simulate people waiting in line.
                      till_show,        # Parameter till_show. Time till show starts.
                      max_time):        # Parameter max_time. Time it takes person to buy ticket.
        pq = Queue()                    # Object of Queue pq. Representing people waiting in line.
        tix_sold = []                   # Instance variable sold. Initilized with empty list value.


        for i in range(100):            
            pq.enqueue("person"\
                       + str(i))        # Insert Number of people to instance variable items.


        t_end = time.time()\
                + till_show             # Final time variable t_end. Equal to sum of initial and difference. 
        now = time.time()               # time.time() is number of seconds that have passed since January 1st, 1970.
        while now < t_end\
        and not pq.is_empty():          # while initial time is less than final time and is not True.
            now = time.time()
            r = random.randint(1,       # random method randint. Select an integer equal to or between START, and STOP value. 
                               max_time)# random.randint(START,STOP)
            time.sleep(r)               # Holds program from proceeding for number of second specified by r.
            person = pq.dequeue()       # pops the last person out of the list.
            print(person)
            tix_sold.append(person)     # adds person to tix_sold list.


        return tix_sold


queue = Queue()
sold = queue.simulate_line(60, 5)
print(sold)

