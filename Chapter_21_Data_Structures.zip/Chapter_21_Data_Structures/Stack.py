# Data Structure stack.


class Stack:
    def __init__(self):     # Magic method __init__.
        self.items = []     # instance variable items.


    def is_empty(self):     # Method is_empty. Returns True if empty, False if not empty.
        return self.items == []


    def push(self, item):   # Method push. Adds items to stack.
        self.items.append(item)


    def pop(self):          # Method pop. Removes last item to stack. Returns removed value.
        return self.items.pop()


    def peek(self):         # Method peek. Looks at last item in stack, returns value.
        last = len(self.items) - 1
        return self.items[last]

    
    def size(self):         # Method size. Returns the length of stack.
        return len(self.items)


# is_empty()

stack = Stack()             # Initalizes Stack object stack.
print(stack.is_empty())     # Returns True. [] == []
stack.items = ['1']
print(stack.is_empty())     # Returns False. ['1'] != []


# push()

stack = Stack()             # Initalizes Stack object stack.
stack.push('1')             # Pushes '1' onto stack.
print(stack.items)


# pop()
          
items = stack.pop()         # Pops last value from stack list. Returns value
print(items)                       


# peek()

stack = Stack()             # Initalizes Stack object stack.
stack.items = ['1', '2', '3', '4', '8']
print(stack.peek())         # Returns value of last item in stack.


# size()

print(stack.size())         # Returns length of the stack.
