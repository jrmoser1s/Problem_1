#indexing list and mutables

fruit = ["Apple", "Orange", "Pear"]
print(fruit[0])
print(fruit[1])
print(fruit[2])

colors = ["blue", "green", "yellow"]
print(colors)
colors[2] = "red"
print(colors)
