#combining lists

colors1 = ["blue", "green", "yellow"]
colors2 = ["orange","pink","black"]
print(colors1 + colors2)
