
my_tuple = tuple()
print(my_tuple)

my_tuple = ()
print(my_tuple)

rndm = ("M. Jackson", 1958, True)
print(rndm)

dys = ("1984",
       "Brave New World",
       "Fahrenheit 451")


print(dys[2])
print("1984" in dys)
print("Handmaid's Tale" not in dys)
