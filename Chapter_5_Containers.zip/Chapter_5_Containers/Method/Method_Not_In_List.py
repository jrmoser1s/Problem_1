#checking if object is in list

colors = ["blue", "green", "yellow"]
print("green" in colors)
if "green" in colors:
    print("Green is in List")
print("black" not in colors)
if"black" not in colors:
    print("Black is not in List")
