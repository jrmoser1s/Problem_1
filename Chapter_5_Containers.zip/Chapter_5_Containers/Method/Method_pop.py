#Using Pop to remove last item from list

colors = ["blue", "green", "yellow"]
print(colors)
item = colors.pop()
print(item)
print(colors)
