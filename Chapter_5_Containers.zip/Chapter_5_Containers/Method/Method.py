#Using Upper and replace Methods

print("Hello".upper())

print("Hello".replace("o","@"))
