#Adding to list using append method

fruit = ["Apple", "Orange", "Pear"]
fruit.append("Banana")
fruit.append("Peach")
print(fruit)

random = []
random.append(True)
random.append(100)
random.append(1.1)
random.append("Hello")
print(random)
