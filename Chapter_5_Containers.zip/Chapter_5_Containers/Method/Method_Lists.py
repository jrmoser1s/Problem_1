#Lists using list() and []

fruit = list()
print(fruit)

fruit = []
print(fruit)

fruit = ["Apple", "Orange", "Pear"]
print(fruit)
