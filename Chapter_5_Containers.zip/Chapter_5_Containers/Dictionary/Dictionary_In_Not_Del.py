# Checking Dictionaries and Deleting Items from Dictionaries

bill = {"Bill Gates":
        "charitable"}

print("Bill Gates" in bill)

print("Bill Doors" not in bill)

books = {"Dracula": "Stoker",
         "1984": "Orwell",
         "The Trial": "Kafka"}

del books["The Trial"]

print(books)
