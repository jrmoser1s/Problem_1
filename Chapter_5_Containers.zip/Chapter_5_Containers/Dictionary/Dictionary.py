#Container Dictionary

my_dict = dict()
print(my_dict)

my_dict = {}
print(my_dict)

fruits = {"Apple",  
         "Red",
         "Banana",
         "Yellow"}
print(fruits)
