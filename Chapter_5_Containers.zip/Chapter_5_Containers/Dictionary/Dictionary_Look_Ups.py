# Dictionary Look-ups

fact = dict()

# add a value
fact["code"] = "fun"
# look up key
print(fact["code"])

# add a value
fact["Bill"] = "Gates"
# look up key
print(fact["Bill"])

# add a value
fact["founded"] = "1776"
# look up key
print(fact["founded"])

print(fact)



