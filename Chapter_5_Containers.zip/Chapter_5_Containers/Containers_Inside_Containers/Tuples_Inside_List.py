# storing tuple inside list

lists = []
la = (34.0522, 188.2437)
chicago = (41.8781, 87.6298)

lists.append(la)
lists.append(chicago)

print(lists)

