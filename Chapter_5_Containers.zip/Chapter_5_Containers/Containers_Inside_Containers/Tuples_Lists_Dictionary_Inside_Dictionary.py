# storing tuples, lists & dictionaries inside dictoinaries

ny = {"location":
      (40.7128,
       74.0059),


      "celebs":
      ["W. Allen",
       "Jay Z",
       "K. Bacon"],


      "facts":
      {"state":
       "NY",
       "country":
       "America"}
}

print(ny["location"])
print(ny["celebs"])
print(ny["facts"])
print(ny)
