# storing lists in tuples

eights = ["Edgar Allen Poe",
          "Charles Dickson"]

nines = ["Hemingway",
         "Fitzgerald",
         "Orwell"]


authors = (eights, nines)
print(authors)
